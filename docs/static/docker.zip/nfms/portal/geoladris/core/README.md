# Geoladris Core 
[![Build Status](https://travis-ci.org/geoladris/core.svg?branch=master)](https://travis-ci.org/geoladris/core)
[![GitHub version](https://badge.fury.io/gh/geoladris%2Fcore.svg)](https://badge.fury.io/gh/geoladris%2Fcore)

Geoladris is a framework for building modular web applications. See [doc](https://geoladris.github.io/doc/) for more details.
