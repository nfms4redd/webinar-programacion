define([ 'module' ], function(module) {
	return module.config().user;
});
