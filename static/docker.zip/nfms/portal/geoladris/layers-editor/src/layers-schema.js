define([ 'text!./layers-schema.json' ], function(shema) {
	return JSON.parse(shema);
});
