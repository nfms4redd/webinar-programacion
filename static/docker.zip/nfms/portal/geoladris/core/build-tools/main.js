'use strict';

module.exports = {
	buildApp : require('./buildApp')
};
